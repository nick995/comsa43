public interface Person {

    String getFirstName();
    String getLastName();
    String getId();
    String getDay();
    String getMonth();
    String getYear();
    Sex getSex();

   

//14
}
