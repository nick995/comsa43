public interface Person {

    String getFirstName();
    String getLastName();
    String getId();
    String getDay();
    String getMonth();
    String getYear();
    Sex getSex();

    String setFirstName();
    String setLastName();
    String setId();
    String setDay();
    String setMonth();
    String setYear();
    Sex setSex();

//14
}
