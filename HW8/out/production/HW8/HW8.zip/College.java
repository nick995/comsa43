public class College extends Student{
    public College(String id, String firstName, String lastName, String sex, String month, String day, String year) {
        super(id, firstName, lastName, sex, month, day, year);
    }



    @Override
    public double getPrice() {
        return 0;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
