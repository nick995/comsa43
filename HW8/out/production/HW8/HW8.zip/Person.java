public interface Person {

    String getFirstName();
    String getLastName();
    String getId();
    String getSex();

}
