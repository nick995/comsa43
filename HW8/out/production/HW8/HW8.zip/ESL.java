public class ESL extends Student {

    private Level level;

    public ESL(String id, String firstName, String lastName, String sex, String month, String day, String year) {
        super(id, firstName, lastName, sex, month, day, year);
        this.level = Level.ESL1A;
    }

    @Override
    public double getPrice() {
        return  25 ;
    }

    @Override
    public String toString() {
        String report = super.toString();
        report += "Price      = " + getPrice();
        return report;
    }
}
