public class Main {

    public static void main(String[] args){
        Student testESLStudent = new ESL("985871450", "Ji-one", "Jung",
                "Female", "03", "25", "1995");
        Student testESLStudent1 = new ESL("3213214","Second", "People",
                "MALE", "01","01","1995");


        ESLStudents esls = new ESLStudents();

        esls.addStudent(testESLStudent);
        esls.addStudent(testESLStudent1);

        System.out.println("The student who you want to find is at " + esls.isFound("985871450"));

        esls.removeStudent("3213214");

        System.out.println(esls);





    }

}
