import java.util.ArrayList;

public class CollegeStudents {

    ArrayList<Student> collegeStudent = new ArrayList<Student>();


    public void addStudent(Student student){
        collegeStudent.add(student);
    }

    public void removeStudent(String id){
        int index = isFound(id);
        if(index >=0){
            collegeStudent.remove(index);
        }
        else{
            System.out.println("There is no student to add");
        }
    }

    public int studentCount(){
        return collegeStudent.size();
    }

    public int isFound(String id){
        for(int i = 0 ; i<collegeStudent.size(); i++){
            if(id.equals(collegeStudent.get(i))){
                return i;
            }
        }
        return -1;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
