

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class LocationTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class LocationTest
{
   @Test
   public void testLocationCon(){
   
       Location myLocation = new Location("WA02Seattle");
       assertEquals("WA02Seattle",     myLocation.getLocationName());
       Customer myCustomer1 = new Customer("ji", "000-000-9704", 200.21);
       myLocation.setStorUnits().getStorUnits(1,1).setCustomer(myCustomer1);
       assertEquals(1,                 myLocation.getCustCount());

   }
}
