public class Location {

    private String locationName;
    private int custCount;
    private double payment;
    private StorUnits [][] storUnits = new StorUnits[12][20];

    public Location(String locationName){

        if(!locationName.matches("[A-Z]{2}+[0-9]]{2}+[A-Z]{1}+[a-z]")){

            throw new IllegalArgumentException("Wrong location name, Please put again" +
                    "ex: WA23Issaqua ");
        }
    }

    public String getLocationName() {
        return locationName;
    }

    public int getCustCount(){
        for(int row = 0; row<12; row++){
            for(int colum = 0; colum<20; colum++){
                if(!storUnits[row][colum].getCustomer().getCustName().isEmpty()
                        || storUnits[row][colum].getCustomer().getCustName() != null){
                    custCount+= 1;
                }
            }
        }
        return custCount;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }


}
