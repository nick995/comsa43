

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class LocationTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class LocationTest
{
   @Test
   public void testLocationCon(){
       //testing constrouctor
       
       Location myLocation = new Location("WA02Seattle");    
              
       assertEquals("WA02Seattle",     myLocation.getLocationName());

       Customer customer1 = new Customer("Jiwon","000-000-0000", 200);
       Customer customer2 = new Customer("Sean", "000-123-1234", 300);
       
       myLocation.addCustomer(customer1);
       myLocation.addCustomer(customer2); 
       //testing customer count
       assertEquals(2,                 myLocation.getCustCount());
       assertEquals(0,  myLocation.getCustomersUnits(customer1).length);
       assertEquals(1,  myLocation.getCustomersUnits(customer2).length);

       
   }    
}
