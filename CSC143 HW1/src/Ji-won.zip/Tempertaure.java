
public class Tempertaure extends StorUnits {
    private final double STORAGE_DISCOUNT = 0.95;

    public Tempertaure() {

    }

    public Tempertaure(double width, double height, double price) {
        super(width, height, price);
    }

    @Override
    public String toString() {
        String report = "";
        report += "TEMPERATURE unit \n";
        report +=  super.toString();
        return report;
    }
}
