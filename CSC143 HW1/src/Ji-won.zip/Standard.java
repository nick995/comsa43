
public class Standard extends StorUnits{

    private final double STORAGE_DISCOUNT = 0.95;

    public Standard(double width, double height, double price) {
        super(width, height, price);
    }

    @Override
    public String toString() {
        String report = "";
        report += "STANDARD unit \n";
        report +=  super.toString();
        return report;

    }

}
