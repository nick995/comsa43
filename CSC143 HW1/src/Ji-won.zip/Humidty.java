
public class Humidty extends StorUnits {
    private final double HUMIDITY = 5;
    private final double oneMeterToFeet = 10.7639104;
    public Humidty() {

    }

    public Humidty(double width, double height, double price) {
        super(width, height, price);
    }


    @Override
    public double getRentedPrice() {
        double rentedPrice;
        rentedPrice = super.getRentedPrice()+HUMIDITY*super.getHeight()*super.getWidth()*oneMeterToFeet;
        return Math.round(rentedPrice);

    }

    @Override
    public String toString() {
        String report = "";
        report += "HUMIDTY unit \n";
        report +=  super.toString();
        return report;
    }


}
