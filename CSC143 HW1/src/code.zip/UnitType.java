public enum UnitType {
    STANDARD,HUMIDITY,TEMPER
}
