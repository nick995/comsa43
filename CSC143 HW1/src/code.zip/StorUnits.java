import java.util.Date;

public class StorUnits {

    private double width;
    private double height;
    private double price;
    private Date startDate;
    private UnitType type;
    private Customer customer;
    private double rentedPrice;

    public StorUnits(){this(0.0, 0.0,0.0,
            UnitType.STANDARD);}
    public StorUnits(double width, double height, double price, UnitType type){
        if(height%2 != 0){
            throw new IllegalArgumentException("Height must be always multiples of two");
        }

        if(width%4 != 0){
            throw new IllegalArgumentException("Width must be always multiples of four");
        }

        this.width = width;
        this.height = height;
        this.price = price;
        this.type = type;
        this.customer = customer;


    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }

    public double getPrice() {
        return price;
    }

    public Customer getCustomer() {
        return customer;
    }

    public UnitType getType() {
        return type;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setType(UnitType type) {
        this.type = type;
    }

    public double getRentedPrice() {
        return rentedPrice;
    }

    public void setRentedPrice(double rentedPrice) {
        this.rentedPrice = rentedPrice;
    }



    public void rentUnit(double rentedPrice, Customer customer,Date startDate) {
        this.rentedPrice = rentedPrice;
        this.customer = customer;
        this.startDate = startDate;
        customer.setAcctBalanel(rentedPrice);
    }

    public void unrentUnit() {
        this.rentedPrice = 0;
        this.customer = null;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
