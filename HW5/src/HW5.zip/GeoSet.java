public class GeoSet {

    private String fileName;
    private String[] locname;
    private Location[] locXY;
    private int countLoc;



}
